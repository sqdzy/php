<?php
    return $db = [
        'host'=>'localhost',
        'username'=>'root',
        'password'=>"",
        'database'=>'notebook'
    ];